<?php 
echo $_POST['file'];
 ?>